# Amosclaud

A minimal local model-serving backend built on FastAPI + Hugging Face
`transformers`. Loads a causal-LM once at startup and exposes both a simple
`/generate` endpoint and OpenAI-compatible `/v1/completions` and
`/v1/chat/completions` endpoints, so it can be pointed at by tools that
expect an OpenAI-style API (base URL override).

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # then edit MODEL_NAME etc. as needed
```

## Run

```bash
# reads config from environment variables (see .env.example)
export $(cat .env | xargs)      # or use a tool like python-dotenv / direnv
python app.py
```

Or with uvicorn directly (auto-reload during development):

```bash
uvicorn app:app --host 0.0.0.0 --port 8000 --reload
```

Server starts on `http://localhost:8000`. Model loading happens once at
startup — the first request after boot may need to wait if you hit it before
loading finishes (check `/health`).

## Docker

```bash
docker build -t amosclaud-server .
docker run -p 8000:8000 -e MODEL_NAME=Salesforce/codegen-350M-mono amosclaud-server
```

For GPU inference, use an image with CUDA + `nvidia-docker`/`--gpus all` and
install a CUDA-enabled `torch` build.

## Endpoints

### `GET /health`
Returns load status, model name, device, and load time.

### `POST /generate`
Simple interface:

```bash
curl -X POST http://localhost:8000/generate \
  -H "Content-Type: application/json" \
  -d '{
        "prompt": "def fibonacci(n):",
        "max_new_tokens": 100,
        "temperature": 0.2
      }'
```

### `POST /v1/completions`
OpenAI-compatible completions format — usable as a drop-in base URL for
tools built against the OpenAI completions API:

```bash
curl -X POST http://localhost:8000/v1/completions \
  -H "Content-Type: application/json" \
  -d '{
        "model": "amosclaud",
        "prompt": "// returns the sum of two numbers\nfunction add(",
        "max_tokens": 60
      }'
```

### `POST /v1/chat/completions`
OpenAI-compatible chat format. Messages are flattened into a single prompt
with role markers before generation (works with instruction-tuned models;
plain base models will just continue the text).

```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
        "messages": [
          {"role": "user", "content": "Write a Python function that reverses a string."}
        ],
        "max_tokens": 150
      }'
```

## Choosing a model

`MODEL_NAME` accepts any Hugging Face causal-LM id or local path. A few
starting points:

| Use case              | Example model                          | Notes                     |
|------------------------|-----------------------------------------|----------------------------|
| CPU-friendly / testing | `Salesforce/codegen-350M-mono`          | small, fast to load        |
| Better code quality    | `codellama/CodeLlama-7b-hf`             | needs a GPU with ~16GB VRAM (fp16) |
| General chat           | `mistralai/Mistral-7B-Instruct-v0.2`    | GPU recommended            |

Gated models require `huggingface-cli login` (or an `HF_TOKEN` env var) before
they can be downloaded.

## Notes / limitations

- Single-request generation — no batching or continuous-batching scheduler.
  For production-scale serving with many concurrent requests, consider
  vLLM or text-generation-inference instead; this project favors simplicity
  and being easy to read/modify.
- No streaming responses yet (`stream: true` is not implemented).
- No authentication — put it behind a reverse proxy / API gateway if
  exposing beyond localhost.
- `n > 1` (multiple completions per request) is not supported.
