"""
amosclaud-server
A local model-serving backend for code-generation / general-purpose LLMs.

Loads a Hugging Face causal LM once at startup and exposes:
  - GET  /health                 liveness + model info
  - POST /generate               simple prompt -> completion
  - POST /v1/completions         OpenAI-compatible completions endpoint
  - POST /v1/chat/completions    OpenAI-compatible chat endpoint

Configure via environment variables (see .env.example / README.md):
  MODEL_NAME    HF model id or local path (default: "Salesforce/codegen-350M-mono")
  DEVICE        "cuda", "cpu", or "auto" (default: "auto")
  DTYPE         "float16", "bfloat16", "float32", or "auto" (default: "auto")
  MAX_NEW_TOKENS_DEFAULT   default generation cap (default: 256)
  TRUST_REMOTE_CODE        "true"/"false" (default: "false")
"""

import os
import time
import uuid
import logging
from contextlib import asynccontextmanager
from typing import List, Optional

import torch
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from transformers import AutoModelForCausalLM, AutoTokenizer, TextIteratorStreamer

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("amosclaud-server")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

MODEL_NAME = os.environ.get("MODEL_NAME", "Salesforce/codegen-350M-mono")
DEVICE_CFG = os.environ.get("DEVICE", "auto")
DTYPE_CFG = os.environ.get("DTYPE", "auto")
MAX_NEW_TOKENS_DEFAULT = int(os.environ.get("MAX_NEW_TOKENS_DEFAULT", "256"))
TRUST_REMOTE_CODE = os.environ.get("TRUST_REMOTE_CODE", "false").lower() == "true"

_DTYPE_MAP = {
    "float16": torch.float16,
    "bfloat16": torch.bfloat16,
    "float32": torch.float32,
    "auto": "auto",
}

# ---------------------------------------------------------------------------
# Model holder (populated at startup)
# ---------------------------------------------------------------------------

class ModelState:
    model = None
    tokenizer = None
    device = None
    load_seconds: float = 0.0


state = ModelState()


def resolve_device() -> str:
    if DEVICE_CFG != "auto":
        return DEVICE_CFG
    return "cuda" if torch.cuda.is_available() else "cpu"


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(f"Loading model '{MODEL_NAME}' ...")
    start = time.time()

    state.device = resolve_device()
    dtype = _DTYPE_MAP.get(DTYPE_CFG, "auto")

    state.tokenizer = AutoTokenizer.from_pretrained(
        MODEL_NAME, trust_remote_code=TRUST_REMOTE_CODE
    )
    if state.tokenizer.pad_token is None:
        state.tokenizer.pad_token = state.tokenizer.eos_token

    load_kwargs = dict(trust_remote_code=TRUST_REMOTE_CODE)
    if dtype != "auto":
        load_kwargs["torch_dtype"] = dtype
    else:
        load_kwargs["torch_dtype"] = "auto"

    if state.device == "cuda":
        load_kwargs["device_map"] = "auto"

    state.model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, **load_kwargs)

    if state.device != "cuda":
        state.model.to(state.device)

    state.model.eval()
    state.load_seconds = time.time() - start
    logger.info(
        f"Model '{MODEL_NAME}' loaded on {state.device} in {state.load_seconds:.1f}s"
    )

    yield

    logger.info("Shutting down, releasing model.")
    state.model = None
    state.tokenizer = None


app = FastAPI(title="Amosclaud", version="1.0.0", lifespan=lifespan)

# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------

class GenerateRequest(BaseModel):
    prompt: str
    max_new_tokens: int = Field(default=MAX_NEW_TOKENS_DEFAULT, ge=1, le=4096)
    temperature: float = Field(default=0.2, ge=0.0, le=2.0)
    top_p: float = Field(default=0.95, ge=0.0, le=1.0)
    stop: Optional[List[str]] = None


class GenerateResponse(BaseModel):
    text: str
    model: str
    prompt_tokens: int
    completion_tokens: int
    latency_seconds: float


class CompletionRequest(BaseModel):
    model: Optional[str] = None
    prompt: str
    max_tokens: int = Field(default=MAX_NEW_TOKENS_DEFAULT, ge=1, le=4096)
    temperature: float = Field(default=0.2, ge=0.0, le=2.0)
    top_p: float = Field(default=0.95, ge=0.0, le=1.0)
    stop: Optional[List[str]] = None
    n: int = Field(default=1, ge=1, le=1)  # single completion supported


class ChatMessage(BaseModel):
    role: str
    content: str


class ChatCompletionRequest(BaseModel):
    model: Optional[str] = None
    messages: List[ChatMessage]
    max_tokens: int = Field(default=MAX_NEW_TOKENS_DEFAULT, ge=1, le=4096)
    temperature: float = Field(default=0.2, ge=0.0, le=2.0)
    top_p: float = Field(default=0.95, ge=0.0, le=1.0)
    stop: Optional[List[str]] = None


# ---------------------------------------------------------------------------
# Core generation helper
# ---------------------------------------------------------------------------

def run_generation(
    prompt: str,
    max_new_tokens: int,
    temperature: float,
    top_p: float,
    stop: Optional[List[str]] = None,
):
    if state.model is None or state.tokenizer is None:
        raise HTTPException(status_code=503, detail="Model is not loaded yet")

    start = time.time()
    inputs = state.tokenizer(prompt, return_tensors="pt").to(state.model.device)
    prompt_tokens = inputs["input_ids"].shape[-1]

    do_sample = temperature > 0.0
    gen_kwargs = dict(
        **inputs,
        max_new_tokens=max_new_tokens,
        do_sample=do_sample,
        pad_token_id=state.tokenizer.pad_token_id,
    )
    if do_sample:
        gen_kwargs["temperature"] = temperature
        gen_kwargs["top_p"] = top_p

    with torch.no_grad():
        output_ids = state.model.generate(**gen_kwargs)

    completion_ids = output_ids[0][prompt_tokens:]
    text = state.tokenizer.decode(completion_ids, skip_special_tokens=True)

    if stop:
        for s in stop:
            idx = text.find(s)
            if idx != -1:
                text = text[:idx]

    latency = time.time() - start
    return text, prompt_tokens, completion_ids.shape[-1], latency


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.get("/health")
def health():
    return {
        "status": "ok" if state.model is not None else "loading",
        "model": MODEL_NAME,
        "device": state.device,
        "load_seconds": round(state.load_seconds, 2),
    }


@app.post("/generate", response_model=GenerateResponse)
def generate(req: GenerateRequest):
    text, prompt_tokens, completion_tokens, latency = run_generation(
        req.prompt, req.max_new_tokens, req.temperature, req.top_p, req.stop
    )
    return GenerateResponse(
        text=text,
        model=MODEL_NAME,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        latency_seconds=round(latency, 3),
    )


@app.post("/v1/completions")
def completions(req: CompletionRequest):
    text, prompt_tokens, completion_tokens, latency = run_generation(
        req.prompt, req.max_tokens, req.temperature, req.top_p, req.stop
    )
    return {
        "id": f"cmpl-{uuid.uuid4().hex[:24]}",
        "object": "text_completion",
        "created": int(time.time()),
        "model": req.model or MODEL_NAME,
        "choices": [
            {
                "text": text,
                "index": 0,
                "logprobs": None,
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
        },
    }


def _messages_to_prompt(messages: List[ChatMessage]) -> str:
    parts = []
    for m in messages:
        parts.append(f"<|{m.role}|>\n{m.content}")
    parts.append("<|assistant|>\n")
    return "\n".join(parts)


@app.post("/v1/chat/completions")
def chat_completions(req: ChatCompletionRequest):
    prompt = _messages_to_prompt(req.messages)
    text, prompt_tokens, completion_tokens, latency = run_generation(
        prompt, req.max_tokens, req.temperature, req.top_p, req.stop
    )
    return {
        "id": f"chatcmpl-{uuid.uuid4().hex[:24]}",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": req.model or MODEL_NAME,
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": text},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
        },
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app:app", host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
